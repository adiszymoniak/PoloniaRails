import React from 'react';
import './App.css';

function App() {
  return (
    <div>
      <h1>PoloniaRails</h1>
      <p>Wersja startowa. Tu pojawią się zakładki: Stacje, Linie kolejowe, Przewoźnicy, Rozkłady, Sprzedaż biletów.</p>
    </div>
  );
}

export default App;
