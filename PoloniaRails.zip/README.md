# PoloniaRails
Pełna aplikacja do tworzenia własnych linii kolejowych, stacji, przewoźników, generowania rozkładów i sprzedaży biletów.

## Uruchomienie lokalne
1. Zainstaluj Node.js (https://nodejs.org/)
2. W terminalu w folderze projektu wpisz:
   npm install
   npm start
3. Aplikacja otworzy się w przeglądarce pod adresem http://localhost:3000
